#!/bin/sh

hypnotoad ./script/plan_monitor -s
