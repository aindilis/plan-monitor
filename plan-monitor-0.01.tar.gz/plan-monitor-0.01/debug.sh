#!/bin/sh

# morbo ./script/plan_monitor daemon -l http://*:8080
morbo ./script/plan_monitor daemon -l https://*:8443
# hypnotoad ./script/plan_monitor
