#!/bin/sh

# morbo ./script/plan_monitor daemon -l http://*:8080
morbo ./script/plan_monitor daemon -l http://*:3001


