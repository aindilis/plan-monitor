#!/bin/sh

morbo ./script/websockets.pl daemon -l http://*:3001
