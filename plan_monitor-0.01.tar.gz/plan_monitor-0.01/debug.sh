#!/bin/sh

morbo ./script/plan_monitor daemon -l http://*:8080
